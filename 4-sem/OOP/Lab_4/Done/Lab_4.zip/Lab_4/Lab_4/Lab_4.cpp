﻿#include <iostream>
#include "TaskAndDialogs.h"

int main()
{
	setlocale(LC_ALL, "Russian");
	TaskAndDialogs<double> prog;
}